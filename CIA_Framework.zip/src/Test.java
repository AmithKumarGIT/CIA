import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;

import cia.genric.utils.CreateDriver;
import cia.genric.utils.DataHandlers;

public class Test
{
public static void main (String[] args) throws IOException, InterruptedException
{
	
	//CreateDriver.getDriverInstance();
	//System.out.println(DataHandlers.getDataFromPropertyFile("C:/Users/a.ch.kumar.DIR/eclipse-workspace/FRAMEWORK_CIA/cia.config/config.properties","URL"));

			WebDriver driver = null;
			String browsertype =
					DataHandlers.getDataFromPropertyFile("C:/Users/a.ch.kumar.DIR/eclipse-workspace/FRAMEWORK_CIA/cia.config/config.properties","Browser");
			System.out.println(browsertype);
			String url = 
					DataHandlers.getDataFromPropertyFile("C:/Users/a.ch.kumar.DIR/eclipse-workspace/FRAMEWORK_CIA/cia.config/config.properties","URL");
			System.out.println(url);
			
			if(("ie").equalsIgnoreCase(browsertype.trim()))
			{
				System.setProperty("webdriver.ie.driver","C:/Users/a.ch.kumar.DIR/Downloads/Selenium/IEDriverServer_x64_3.3.0/IEDriverServer.exe");
				Thread.sleep(10000);
				driver = new InternetExplorerDriver();
				Thread.sleep(10000);
				driver.manage().window().maximize();
				driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
				Thread.sleep(10000);
				driver.get(url);
			}
			
			else
			{
				System.out.println("Application will not suport for this browser");
			}
		
			driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
			

		}



}

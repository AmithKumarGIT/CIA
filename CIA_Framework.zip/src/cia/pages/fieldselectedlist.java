package cia.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import cia.base.Testbase;

public class fieldselectedlist extends Testbase {
	//This is the Object Repository for fieldselectedlist
	@FindBy(xpath="//html/body/div[2]/div/div/div/div[2]/div[2]/div[3]/div[3]/button")
	WebElement fieldselectedlists;
	// initializing the object
	public fieldselectedlist() {
		PageFactory.initElements(driver,this );
}
	public void fieldselected() {
		
		fieldselectedlists.click();
	
	}
}
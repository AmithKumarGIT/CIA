package cia.pages;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import cia.base.Testbase;


public class Loginpage extends Testbase {
	
	
	//Page Factory  OBJECT Repository Till Login Page
	@FindBy(partialLinkText="More information")
	WebElement Moreinformation;
	@FindBy(partialLinkText="Go on to the webpage (not recommended)")
	WebElement Goontothewebpagenotrecommended;
	@FindBy(name="userid")
	WebElement userid;
	@FindBy(name="password")
	WebElement password;
	@FindBy(name="btnSubmit")
	WebElement btnSubmit;
	@FindBy(name="successOK")
	WebElement successOK;
	
	//Initializing the page Objects:
	public Loginpage() {
		PageFactory.initElements(driver, this);
	}
	//Actions
	public void GotoLogin() {
		Moreinformation.click();
		Goontothewebpagenotrecommended.click();
		}
	public void loginpage(String un, String pwd) throws IOException 
	{
		userid.sendKeys(un);
		password.sendKeys(pwd);
		/*File file = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
		FileUtils.copyFile(file, new File("C:/Users/a.ch.kumar.DIR/eclipse-workspace/FRAMEWORK_CIA/screenshot1"+file+".jpg"));*/
		//screenshot.takescreenshot("loginpage");
		btnSubmit.click();
		successOK.click();
		}
}

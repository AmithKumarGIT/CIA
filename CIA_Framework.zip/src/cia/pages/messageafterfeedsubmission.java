package cia.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import cia.base.Testbase;

public class messageafterfeedsubmission extends Testbase {
	//This is the object Repository for acknowledge page after feed submission
	@FindBy(xpath="html/body/div[2]/div/div/div/div[2]/div[2]/div[3]/a/button")
	WebElement ok;
	// initializing the object
	public messageafterfeedsubmission() {
	PageFactory.initElements(driver,this );
	}
	//Actions
	public void Acknowledged() {
		ok.click();
	}

}

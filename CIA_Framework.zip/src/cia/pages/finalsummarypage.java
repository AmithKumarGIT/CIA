package cia.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import cia.base.Testbase;

public class finalsummarypage extends Testbase {
	//This is the object Repository of finalsummarypage
	@FindBy(xpath="html/body/div[2]/div/div/div/div[2]/div[2]/div[3]/div[5]/a/button")
	WebElement Submit;
	// initializing the object
	public finalsummarypage() {
	PageFactory.initElements(driver,this );
	}
	public void finalsubmitoffeed() {
		Submit.click();
	}
}

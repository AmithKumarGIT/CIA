package cia.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import cia.base.Testbase;

public class RemindMeLater extends Testbase {
	
	//Page Factory  OBJECT Repository for Remind me later page
	//This Page currently not in use
	@FindBy(name="successOK")
	WebElement successOK;
}

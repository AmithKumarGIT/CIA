package cia.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import cia.base.Testbase;

public class FieldSelection extends Testbase {
	
	// this is the object repository of field selection page
	@FindBy(xpath="//Select[@id='test1']/option[5]")
	WebElement AvailableField;
	@FindBy(id="moveright")
	WebElement clickadd;
	@FindBy(id="r1")
	WebElement Encrypt;
	@FindBy(id="text_area")
	WebElement TextField;
	@FindBy(id="Next_id")
	WebElement Next;
	
	public FieldSelection() {
		PageFactory.initElements(driver, this);
	}
	public void selectfield() { 
		AvailableField.click();
		clickadd.click();
		Encrypt.click();
		TextField.sendKeys("automatio is being done.");
		Next.click();
	}
	

}

package cia.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

import cia.base.Testbase;

public class FeedRequestForm extends Testbase {
	
	//This is the object repository of feed request page
	//DropDown
	WebElement requesttype_dropdown = driver.findElement(By.id("req_typ_id"));
	Select req_typ_id = new Select(requesttype_dropdown);
	WebElement Transmissionmode_dropdown = driver.findElement(By.id("trans_id"));
	Select trans_id = new Select(Transmissionmode_dropdown);
	WebElement Required_file_format = driver.findElement(By.id("rqFileFormat_id"));
	Select rqFileFormat_id = new Select(Required_file_format);
	WebElement scheduleofthefeed = driver.findElement(By.id("scheduleId"));
	Select scheduleId = new Select(scheduleofthefeed);
	
	//HandlingCalender
  @FindBy(css="#FeedStartId")
        WebElement Clear;
  @FindBy(css="#FeedStartId")
        WebElement Enterdate;
      //TestField dummydata
		By VendorId = By.id("Vendor_id");
		By Applname = By.id("App_name_id");
		By AppDesc  = By.id("app_desc_id");
		By vendorname = By.id("VendorName_id");
		By IPAddress = By.id("ipAdd_id");
		By Serverlocation = By.id("phys_loc_id");
		By nameofffedfile = By.id("feed_name_id");
		By businessneed = By.id("txtAreaId");
		By feedchangerequirement = By.id("txtAreaId1");
		By Inabsenceofcenetfeed = By.id("txtAreaId2");
		By schedulefeed = By.id("time_id");
		//TestFieldAuthenticdata
    	By SponsorATTUID = By.id("Bus_sponsr_id");
    	By directorATTUID = By.id("Bus_unitDirectr_id");
    	By techanicalsupportATTUID = By.id("tech_sup_id");
    	By SubscriberAttuid = By.id("AuthSub_id");
    	//ClickNextButton
    	By nextbutton = By.id("next_id");
    	//Initializing the object
    	public FeedRequestForm() {
    		PageFactory.initElements(driver,this);
    	}
    	public void dropdown() {
    		req_typ_id.selectByVisibleText("New Feed");
    		trans_id.selectByVisibleText("SFG");
    		rqFileFormat_id.selectByVisibleText("Comma Delimited(,)");
    		scheduleId.selectByVisibleText("1");
    	}
    	public void radiobutton() throws InterruptedException {
    		//RadioButton
    		//WebElement IPADDRESSLOCATED = driver.findElement(By.id("4_radio"));
    		//IPADDRESSLOCATED.click();
    		WebElement frequencyofthefeed = driver.findElement(By.id("5_radio"));
    		WebElement frequencyofthefeed1 = driver.findElement(By.id("6_radio"));
    		boolean Boolean = frequencyofthefeed.isSelected();
    		if(Boolean) {
    			frequencyofthefeed1.click();
    		}
    		else {
    			frequencyofthefeed.click();
    		}
    		
    		frequencyofthefeed1.click();
    		WebElement headerrequired = driver.findElement(By.id("8_radio"));
    		WebElement headerrequired1 = driver.findElement(By.id("9_radio"));
    		boolean Boolean1 = headerrequired.isSelected();
    		if(Boolean1) {
    			headerrequired1.click();
    		}
    		else {
    			headerrequired.click();
    		}
    		WebElement countrequired = driver.findElement(By.id("11_radio"));
    		WebElement countrequired1 = driver.findElement(By.id("10_radio"));
    		boolean Boolean2 = countrequired.isSelected();
    		if(Boolean2) {
    			countrequired1.click();
    		}
    		else {
    			countrequired.click();
    		}
    		WebElement feedsenttovendor = driver.findElement(By.id("1_radio"));
    		WebElement feedsenttovendor1 = driver.findElement(By.id("2_radio"));
    		boolean Boolean3 = feedsenttovendor.isSelected();
    		if(Boolean3) {
    			feedsenttovendor1.click();
    			Thread.sleep(2000);
    		}
    		else {
    			feedsenttovendor.click();
    			Thread.sleep(2000);
    		}	
    	}
    	public void calender() {
    		Clear.clear();
    		Enterdate.sendKeys("10/10/2019");
    	}
    	public void dummydata() {
    		driver.findElement(Applname).clear();
    		driver.findElement(Applname).sendKeys("Test");
    		driver.findElement(AppDesc).clear();
			driver.findElement(AppDesc).sendKeys("Test_app");
			driver.findElement(vendorname).clear();
			driver.findElement(vendorname).sendKeys("Test");
			driver.findElement(VendorId).clear();
			driver.findElement(VendorId).sendKeys("2022");
			driver.findElement(IPAddress).clear();
			driver.findElement(IPAddress).sendKeys("12.3.6");
			driver.findElement(Serverlocation).clear();
			driver.findElement(Serverlocation).sendKeys("ATLANTA");
			driver.findElement(nameofffedfile).clear();
			driver.findElement(nameofffedfile).sendKeys("Test_app");
			driver.findElement(businessneed).clear();
			driver.findElement(businessneed).sendKeys("Test");
			driver.findElement(feedchangerequirement).clear();
            driver.findElement(feedchangerequirement).sendKeys("cenet feed wes testing.cenet feed wes testing.cenet feed wes testing");
            driver.findElement(Inabsenceofcenetfeed).clear();
            driver.findElement(Inabsenceofcenetfeed).sendKeys("cenet feed wes testing.cenet feed wes testing.cenet feed wes testingcenet feed wes testing.cenet feed wes testing");
            driver.findElement(schedulefeed).clear();
            driver.findElement(schedulefeed).sendKeys("10AM");
    	}
    	public void Authenticdata() {
    		driver.findElement(SponsorATTUID).clear();
    		driver.findElement(SponsorATTUID).sendKeys(prop.getProperty("ATTUID"));
    		driver.findElement(directorATTUID).clear();
        	driver.findElement(directorATTUID).sendKeys(prop.getProperty("ATTUID"));
        	driver.findElement(techanicalsupportATTUID).clear();
        	driver.findElement(techanicalsupportATTUID).sendKeys(prop.getProperty("ATTUID"));
        	driver.findElement(SubscriberAttuid).clear();
        	driver.findElement(SubscriberAttuid).sendKeys(prop.getProperty("ATTUID"));
    	}
    	
    	public void nextbutton() throws InterruptedException {
    		driver.findElement(nextbutton).click();
    		Thread.sleep(2000);
    	}
    	

}

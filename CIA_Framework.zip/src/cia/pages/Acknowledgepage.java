package cia.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import cia.base.Testbase;

public class Acknowledgepage extends Testbase {
	
	//Page Factory  OBJECT Repository For Acknowledge Page
	@FindBy(xpath="//button[@ng-click='updateAckFlag()']")
	WebElement AcknowledgePage; 
	
	// initializing the object
	public Acknowledgepage() {
		PageFactory.initElements(driver,this );
	}
	public void Acknowledge(){
		 boolean Boolean = AcknowledgePage.isDisplayed();
		 if(Boolean) {
			 AcknowledgePage.click();
		 }
		 else {
			 System.out.println("ALREADYACKNOWLEDGE");
		 }
}
	/*public void click() {
		AcknowledgePage.click();
	}*/
}

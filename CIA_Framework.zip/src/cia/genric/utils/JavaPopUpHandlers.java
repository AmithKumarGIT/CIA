package cia.genric.utils;

import org.openqa.selenium.Alert;
import org.openqa.selenium.WebDriver;

public class JavaPopUpHandlers 
{

	public static void clickOkOnPopUp(WebDriver driver)
	{
		Alert alt = driver.switchTo().alert();
		alt.accept();
		
	}
	public static void clickCancelOnPopUp(WebDriver driver)
	{
		Alert alt = driver.switchTo().alert();
		alt.dismiss();
		
	}
	public static String getPopUpMessage(WebDriver driver)
	{
		Alert alt = driver.switchTo().alert();
		String popUpMsg=alt.getText();
		return popUpMsg;
	}
	public static void enterTextOnPopUp(WebDriver driver,String text)
	{
		Alert alt = driver.switchTo().alert();
		alt.sendKeys(text);
	}
}

package cia.genric.utils;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import org.testng.annotations.Test;

public class DatabaseValidation {
	Connection connection = null;

	@Test
	public void dbCheck(String sql) throws Exception {
		// String path =
		// "C:\\Users\\ramakrushna.a.sahoo\\Documents\\Client_Confidential\\Selenium\\BPS\\BPS_Testdata";
		// readExcelFile cred = new readExcelFile();
		/*
		 * String dbUser = cred.readExcel(path,"BPS.xlsx","Login",4,1); String
		 * dbPasswd = cred.readExcel(path,"BPS.xlsx","Login",4,2);
		 * EncryptDecrypt td= new EncryptDecrypt(); String
		 * decrypted=td.decrypt(dbPasswd);
		 */
		// System.out.println("String To Encrypt: "+ dbPasswd);

		System.out.println("-------- Oracle JDBC Connection Testing ------");

		try {

			Class.forName("oracle.jdbc.driver.OracleDriver");

		} catch (ClassNotFoundException e) {

			System.out.println("Where is your Oracle JDBC Driver?");
			e.printStackTrace();
			return;

		}

		System.out.println("Oracle JDBC Driver Registered!");

		// Connection connection = null;

		try {

			/*
			 * connection = DriverManager.getConnection(
			 * "jdbc:oracle:thin:@zld02167.vci.att.com:1524:d1c1d972", dbUser,
			 * decrypted);
			 */

			connection = DriverManager.getConnection("jdbc:oracle:thin:@zlt06457.vci.att.com:1524:t1c3d832", "NMICQC",
					"glad2srv");

		} catch (SQLException e) {

			System.out.println("Connection Failed! Check output console");
			e.printStackTrace();
			return;

		}

		if (connection != null) {
			System.out.println("Taking control of database now!");

		} else {
			System.out.println("Failed to make connection!");
		}

		try {

			// creating PreparedStatement object to execute query
			Statement preStatement = connection.createStatement();

			preStatement.executeQuery(sql);

		}

		catch (SQLException e) {

			System.out.println("Query failed in dbValue method!");
			e.printStackTrace();

		}
	}

	public String dbValue(String sql, String returnString) {

		try {

			// creating PreparedStatement object to execute query
			PreparedStatement preStatement = connection.prepareStatement(sql);
			String retVal = null;

			ResultSet result = preStatement.executeQuery();
			if (null != result) {
				while (result.next()) {
					retVal = result.getString(returnString);
				}
			}
			/*
			 * result.next(); String strValue = result.getString(returnString);
			 * System.out.println(strValue); return strValue;
			 */
			return retVal;
		} catch (SQLException e) {

			System.out.println("Query failed in dbValue method!");
			e.printStackTrace();
			return "Error";

		}

	}

}

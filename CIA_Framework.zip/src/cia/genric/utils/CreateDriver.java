package cia.genric.utils;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;

public class CreateDriver {

	public static WebDriver getDriverInstance() throws IOException, InterruptedException
	{
		WebDriver driver = null;
		String browser_type =
				DataHandlers.getDataFromPropertyFile("C:/Users/a.ch.kumar.DIR/eclipse-workspace/FRAMEWORK_CIA/cia.config/config.properties","Browser");
		String url = 
				DataHandlers.getDataFromPropertyFile("C:/Users/a.ch.kumar.DIR/eclipse-workspace/FRAMEWORK_CIA/cia.config/config.properties","URL");
		
		if(browser_type.trim().toLowerCase().equals("ie"))
		{
			System.setProperty("webdriver.ie.driver","C:/Users/a.ch.kumar.DIR/Downloads/Selenium/IEDriverServer_x64_3.3.0/IEDriverServer.exe");
			Thread.sleep(10000);
			driver = new InternetExplorerDriver();
			Thread.sleep(10000);
			driver.manage().window().maximize();
			driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
			Thread.sleep(10000);
			driver.get(url);
		}
		else
		{
			System.out.println("--------------Application is not compatible with selected browser-----------------");
		}
		
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		return driver;

	}

}

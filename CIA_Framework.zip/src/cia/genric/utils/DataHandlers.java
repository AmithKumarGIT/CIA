package cia.genric.utils;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Properties;





public class DataHandlers 
{
	public static String getDataFromPropertyFile(String fileName,String key) throws IOException
	{
		String value = null;
		try 
		{

			File f = new File(fileName);
			FileInputStream fis = new FileInputStream(f);
			Properties prop = new Properties();
			prop.load(fis);
			value=(String) prop.get(key);			
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		return value;			
	}
	
	public static void loadDataToPropertyFile(String fileName,String key,String value,String comments) throws IOException
	{
		try 
		{
			File f = new File(fileName);
			FileInputStream fis = new FileInputStream(f);
			Properties prop = new Properties();
			prop.load(fis);
			prop.setProperty(key, value);	
			FileOutputStream fos = new FileOutputStream(f);
			prop.store(fos, comments);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}			
	}
	/*public static String getDataFromExcel(String fileName,String sheetName,int rowIndexValue,int cellIndexValue)
	{
		String value=null;
		try
		{
		String path = "C:/Users/vasanth.f.kumar.DIR/Desktop/SSAR/nmic_ssar/test-data/"+fileName+".xlsx";
		File f = new File(path);
		FileInputStream fis = new FileInputStream(f);
		Workbook wb =  WorkbookFactory.create(fis);
		Sheet s = wb.getSheet(sheetName);
		Row r = s.getRow(rowIndexValue);
		Cell c = r.getCell(cellIndexValue);
		value =c.toString();
				
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		return value;
	}
	public static void loadDataToExcel(String fileName,String sheetName,int rowIndexValue,int cellIndexValue,String value)  
	{	
		try
		{
		File f = new File(fileName);
		FileInputStream fis = new FileInputStream(f);
		Workbook wb =  WorkbookFactory.create(fis);
		Sheet s = wb.getSheet(sheetName);
		Row r = s.getRow(rowIndexValue);
		Cell c = r.getCell(cellIndexValue);
		c.setCellValue(value);
		FileOutputStream fos = new FileOutputStream(f);
		wb.write(fos);		
		}catch(Exception e)
		{
			e.printStackTrace();
		}
	}
*/
}

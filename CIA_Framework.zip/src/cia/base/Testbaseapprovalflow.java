package cia.base;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.DesiredCapabilities;

import cia.util.TestUtil;

public class Testbaseapprovalflow {
	public static WebDriver driver;
	 public static Properties prop;
	 
	 public Testbaseapprovalflow() {
		 try {
			 
			 prop = new Properties();
			 FileInputStream ip = new FileInputStream("C:\\Users\\a.ch.kumar.DIR\\eclipse-workspace\\FRAMEWORK_CIA\\src\\conf\\properties\\conf.properties");
			 prop.load(ip);
		 }catch(FileNotFoundException e) {
			 e.printStackTrace(); 
			 
		 } catch (IOException e) {
			e.printStackTrace();
		}
	 }
	 public static void initialization() {
		 String browser =prop.getProperty("browser");
		 if(browser.equals("IE")) {
			 System.setProperty("webdriver.ie.driver","C:/Users/a.ch.kumar.DIR/Downloads/Selenium/IEDriverServer_x64_3.3.0/IEDriverServer.exe");
			 driver = new InternetExplorerDriver();
		 }
		 else if(browser.equals("chrome")) {
			 //set property for chrome
		 }
		 else if (browser.equals("firefox")) {
			 //set property for firefox
		 }
		driver.manage().window().maximize();
		driver.manage().deleteAllCookies();
		driver.manage().timeouts().pageLoadTimeout(TestUtil.PAGE_LOAD_TIMEOUT, TimeUnit.SECONDS);
		driver.manage().timeouts().implicitlyWait(TestUtil.IMPLICIT_WAIT, TimeUnit.SECONDS);
		driver.get(prop.getProperty("url"));
		
	 }
}

package cia.test;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import cia.base.Testbase;
import cia.pages.FeedRequestForm;
import cia.pages.FieldSelection;
import cia.pages.Loginpage;
import cia.pages.fieldselectedlist;

public class FieldsSelectedList extends Testbase{
	   Loginpage loginpage;
	   AcknowledgePage acknowledge;
	   FeedRequestForm feedform;
	   FieldSelection fieldselection;
	   fieldselectedlist fieldlists;
	   public FieldsSelectedList() {
	    	 super();
	     }
	   @BeforeMethod()
	     public void setup() throws IOException, InterruptedException {
		    initialization();
	        loginpage = new Loginpage();
			loginpage.GotoLogin();
			loginpage.loginpage(prop.getProperty("username"), prop.getProperty("password"));
			acknowledge = new AcknowledgePage();
			acknowledge.acknowledge();
			Thread.sleep(3000);
			feedform = new FeedRequestForm();
			feedform.dropdown();
			feedform.dummydata();
			feedform.Authenticdata();
			feedform.calender();
			feedform.radiobutton();
			feedform.nextbutton();
			fieldselection = new FieldSelection();
        	fieldselection.selectfield();
	   }
	   @Test()
	   public void selectedfielddisplayed() {
		   //driver.findElement(By.xpath("//button[contains(@class='btn cenet-inv-button')]")).click();
		   //driver.findElement(By.xpath("//*[contains(@class='btn cenet-inv-button' and @ng-click='nextHeader()')]")).click();
		   //driver.findElement(By.xpath("//html/body/div[2]/div/div/div/div[2]/div[2]/div[3]/div[3]/button")).click();
		   //fieldselectedlist.click();
		   //fieldselectedlists.fieldselected();
		   fieldlists = new fieldselectedlist();
		   fieldlists.fieldselected();
	   }
	   
	   
	   /*@AfterMethod()
       public void closedriver() {
 		driver.quit();

}*/
}

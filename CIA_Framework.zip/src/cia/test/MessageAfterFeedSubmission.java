package cia.test;

import java.io.IOException;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import cia.base.Testbase;
import cia.pages.FeedRequestForm;
import cia.pages.FieldCriteria;
import cia.pages.FieldSelection;
import cia.pages.Loginpage;
import cia.pages.fieldselectedlist;
import cia.pages.finalsummarypage;
import cia.pages.messageafterfeedsubmission;

public class MessageAfterFeedSubmission extends Testbase{
	Loginpage loginpage;
	   AcknowledgePage acknowledge;
	   FeedRequestForm feedform;
	   FieldSelection fieldselection;
	   fieldselectedlist fieldlists;
	   FieldCriteria criteria;
	   finalsummarypage summary;
	   messageafterfeedsubmission clickok;
	   public  MessageAfterFeedSubmission() {
	    	 super();
	     }
	   
	     @BeforeMethod()
	     public void setup() throws IOException, InterruptedException {
		    initialization();
	        loginpage = new Loginpage();
			loginpage.GotoLogin();
			loginpage.loginpage(prop.getProperty("username"), prop.getProperty("password"));
			acknowledge = new AcknowledgePage();
			acknowledge.acknowledge();
			Thread.sleep(1000);
			feedform = new FeedRequestForm();
			feedform.dropdown();
			feedform.dummydata();
			feedform.Authenticdata();
			feedform.calender();
			feedform.radiobutton();
			feedform.nextbutton();
			fieldselection = new FieldSelection();
	        fieldselection.selectfield();
	        fieldlists = new fieldselectedlist();
		    fieldlists.fieldselected();
		    criteria = new FieldCriteria();
		    criteria.FieldCriteriapa();
		    summary = new  finalsummarypage();
	    	summary.finalsubmitoffeed();
}
	   @Test()
	   public void feedsubmittedsuccessfully() {
		   clickok = new messageafterfeedsubmission();
		   clickok.Acknowledged();
		   
	   }
	     
	     @AfterMethod()
	       public void closedriver() {
	 		driver.quit();
	 		}

}

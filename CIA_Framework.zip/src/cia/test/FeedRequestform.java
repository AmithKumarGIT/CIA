package cia.test;

import java.io.IOException;

import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import cia.base.Testbase;
import cia.pages.FeedRequestForm;
import cia.pages.Loginpage;

public class FeedRequestform extends Testbase {
	Loginpage loginpage;
	AcknowledgePage acknowledge;
	FeedRequestForm feedform;
	
	public FeedRequestform() {
	super();
	}
	@BeforeMethod()
	public void setup() throws IOException {
		initialization();
		loginpage = new Loginpage();
		loginpage.GotoLogin();
		loginpage.loginpage(prop.getProperty("username"), prop.getProperty("password"));
		acknowledge = new AcknowledgePage();
		acknowledge.acknowledge();
		}
	@Test
	public void feedrequestform() throws InterruptedException {
		feedform = new FeedRequestForm();
		feedform.dropdown();
		feedform.dummydata();
		feedform.Authenticdata();
		feedform.calender();
		feedform.radiobutton();
		feedform.nextbutton();
		
	}
	@AfterMethod()
	public void closedriver() {
		driver.quit();
	}
}

package cia.test;

import java.io.IOException;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import cia.base.Testbase;
import cia.pages.Loginpage;
import cia.pages.Screenshot;


public class LoginPageTest extends Testbase  {
	Loginpage loginpage;
	
	
	public LoginPageTest() {
		super();
	}
	@BeforeMethod()
	public void setup()
	{
		initialization();
		loginpage = new Loginpage();
		
		}
	@Test()
	public void GoLogin() throws IOException {
		loginpage.GotoLogin();
		Screenshot.capturescreenshot(driver, "loginpage");
		loginpage.loginpage(prop.getProperty("username"), prop.getProperty("password"));
	}
	
	
	@AfterMethod()
	public void closedriver() {
		driver.quit();
	}
	
}



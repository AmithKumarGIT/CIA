package cia.test;

import java.io.IOException;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import cia.base.Testbase;
import cia.pages.FeedRequestForm;
import cia.pages.FieldSelection;
import cia.pages.Loginpage;

public class Fieldselectionpage extends Testbase {
	   Loginpage loginpage;
	   AcknowledgePage acknowledge;
	   FeedRequestForm feedform;
	   FieldSelection fieldselection;
	   
     public Fieldselectionpage() {
    	 super();
     }
     @BeforeMethod()
     public void setup() throws IOException, InterruptedException {
    	 initialization();
        loginpage = new Loginpage();
		loginpage.GotoLogin();
		loginpage.loginpage(prop.getProperty("username"), prop.getProperty("password"));
		acknowledge = new AcknowledgePage();
		acknowledge.acknowledge();
		Thread.sleep(10000);
		feedform = new FeedRequestForm();
		feedform.dropdown();
		feedform.dummydata();
		feedform.Authenticdata();
		feedform.calender();
		feedform.radiobutton();
		feedform.nextbutton();
		}
        @Test()
        public void Fieldselection() {
        	fieldselection = new FieldSelection();
        	fieldselection.selectfield();
        }
      /*@AfterMethod()
       public void closedriver() {
 		driver.quit();
 	}*/
}
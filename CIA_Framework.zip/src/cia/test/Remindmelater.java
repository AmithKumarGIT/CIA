package cia.test;

import cia.base.Testbase;

public class Remindmelater extends Testbase {
	//this is the object repository of remind me later page
    //This Page currently not in use
}

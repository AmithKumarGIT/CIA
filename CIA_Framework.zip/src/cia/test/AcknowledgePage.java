package cia.test;

import java.io.IOException;

import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import cia.base.Testbase;
import cia.pages.Acknowledgepage;
import cia.pages.Loginpage;

public class AcknowledgePage extends Testbase {
	Loginpage loginpage;
	Acknowledgepage acknowledge;
	public AcknowledgePage() {
		super();
	}
	@BeforeMethod()
	public void setup() throws IOException {
		initialization();
		loginpage = new Loginpage();
		loginpage.GotoLogin();
		loginpage.loginpage(prop.getProperty("username"), prop.getProperty("password"));
	}
	@Test()
	public void acknowledge()
	{
		acknowledge = new Acknowledgepage();
		/*boolean flag = acknowledge.Acknowledge();
				if(flag == true) {
					acknowledge.click();
				}*/
		acknowledge.Acknowledge();			
	}
	@AfterMethod()
	public void closedriver() {
		driver.quit();
	}
}

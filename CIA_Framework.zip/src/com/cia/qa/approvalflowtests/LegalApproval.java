package com.cia.qa.approvalflowtests;

import java.io.IOException;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.cia.qa.approvalflowpages.Approvefeedmenu;
import com.cia.qa.approvalflowpages.Clickonwesid;
import com.cia.qa.approvalflowpages.L1approval;
import com.cia.qa.approvalflowpages.Legalapproval;
import com.cia.qa.approvalflowpages.Loginpageapproval;

import cia.base.Testbaseapprovalflow;

public class LegalApproval extends Testbaseapprovalflow {
	Loginpageapproval loginpage;
    Approvefeedmenu feedmenu;
    Clickonwesid Clickwesid;
    Legalapproval  approvallegal;
	public LegalApproval() {
		super();
	}
	@BeforeMethod()
	public void setup() throws IOException
	{
		initialization();
		loginpage = new Loginpageapproval();
		loginpage.GotoLogin();
		loginpage.loginpage(prop.getProperty("legalusername"), prop.getProperty("legalpassword"));
		feedmenu = new Approvefeedmenu();
		feedmenu.Feedmenuforapproval();
		
		}
	@Test()
	public void Givelegalapproval() {
		Clickwesid = new Clickonwesid();
		int s=Clickwesid.clickonwesids();
		if(s==2) {
		approvallegal = new Legalapproval();
		approvallegal.providelegalapproval();
		
	}
		else {
			System.out.println("Legal Approval not required");
		}
		}
	
	@AfterMethod()
	public void closedriver() {
		driver.quit();
	}

}

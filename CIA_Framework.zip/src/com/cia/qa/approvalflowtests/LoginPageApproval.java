package com.cia.qa.approvalflowtests;

import java.io.IOException;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.cia.qa.approvalflowpages.Loginpageapproval;

import cia.base.Testbaseapprovalflow;
import cia.pages.Loginpage;

public class LoginPageApproval extends Testbaseapprovalflow {
Loginpageapproval loginpage;
	
	
	public LoginPageApproval() {
		super();
	}
	@BeforeMethod()
	public void setup()
	{
		initialization();
		loginpage = new Loginpageapproval();
		
		}
	@Test()
	public void GoLogin() throws IOException {
		loginpage.GotoLogin();
		loginpage.loginpage(prop.getProperty("l1username"), prop.getProperty("l1password"));
		
	}
	
	
	@AfterMethod()
	public void closedriver() {
		driver.quit();
	}
	


}

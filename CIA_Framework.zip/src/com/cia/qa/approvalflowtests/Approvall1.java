package com.cia.qa.approvalflowtests;

import java.io.IOException;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.cia.qa.approvalflowpages.Approvefeedmenu;
import com.cia.qa.approvalflowpages.Clickonwesid;
import com.cia.qa.approvalflowpages.L1approval;
import com.cia.qa.approvalflowpages.Loginpageapproval;

import cia.base.Testbaseapprovalflow;
import cia.pages.Loginpage;

public class Approvall1 extends Testbaseapprovalflow{
	Loginpageapproval loginpage;
    Approvefeedmenu feedmenu;
    Clickonwesid Clickwesid;
    L1approval approval1;
	
	
	public Approvall1() {
		super();
	}
	@BeforeMethod()
	public void setup() throws IOException
	{
		initialization();
		loginpage = new Loginpageapproval();
		loginpage.GotoLogin();
		loginpage.loginpage(prop.getProperty("l1username"), prop.getProperty("l1password"));
		feedmenu = new Approvefeedmenu();
		feedmenu.Feedmenuforapproval();
		Clickwesid = new Clickonwesid();
		Clickwesid.clickonwesids();
		}
	@Test()
	public void Givel1approval() {
		approval1 = new L1approval();
		approval1.providel1approval();
	}
	
	
	
	@AfterMethod()
	public void closedriver() {
		driver.quit();
	}

}

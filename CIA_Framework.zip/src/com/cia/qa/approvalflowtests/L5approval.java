package com.cia.qa.approvalflowtests;

import java.io.IOException;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.cia.qa.approvalflowpages.Approvefeedmenu;
import com.cia.qa.approvalflowpages.Clickonwesid;
import com.cia.qa.approvalflowpages.L4Approval;
import com.cia.qa.approvalflowpages.L5Approval;
import com.cia.qa.approvalflowpages.Loginpageapproval;

import cia.base.Testbaseapprovalflow;

public class L5approval extends Testbaseapprovalflow{
	Loginpageapproval loginpage;
    Approvefeedmenu feedmenu;
    Clickonwesid Clickwesid;
    L5Approval approval5;
	
	
	public L5approval() {
		super();
	}
	@BeforeMethod()
	public void setup() throws IOException
	{
		initialization();
		loginpage = new Loginpageapproval();
		loginpage.GotoLogin();
		loginpage.loginpage(prop.getProperty("l5username"), prop.getProperty("l5password"));
		feedmenu = new Approvefeedmenu();
		feedmenu.Feedmenuforapproval();
		Clickwesid = new Clickonwesid();
		Clickwesid.clickonwesids();
		}
	@Test()
	public void Givel1approval() throws InterruptedException {
		approval5 = new L5Approval();
		approval5.provideL2approval();
		approval5.ClickOK();}
		
		@AfterMethod()
		public void closedriver() {
			driver.quit();
		
}}





package com.cia.qa.buttoncheckpages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import cia.base.Testbase;

public class Buttonfeedrequestform extends Testbase {
	//This is the object repository for buuton element for FeedRequestform
	@FindBy(xpath="html/body/div[2]/div/div/div/div[2]/"
			+ "div[2]/form/div/table/tbody/tr[24]/td/a/button")
	WebElement Back;
	@FindBy(xpath="//button[@ng-click='saveFormData(save)']")
	WebElement Save;
	@FindBy(xpath="//button[@ng-click='radioCancel()']")
	WebElement CancelFeedRequest;
	@FindBy(xpath="html/body/div[2]/div/div/div/div[2]/div[2]/div[5]/a/button")
	WebElement MainMenu;
	@FindBy(xpath="//button[@ng-click='radioSelect()']")
	WebElement ModifyFeedRequest;
	@FindBy(xpath="//button[@ng-click='search()']")
	WebElement Search;
	@FindBy(xpath="//button[@ng-click='exportToExcel('#tableToExport')']")
	WebElement exportToExcel;
	// initializing the object
		public Buttonfeedrequestform() {
		PageFactory.initElements(driver,this );
		}
		//Actions
		public boolean Backbutton() {
			boolean Boolean = Back.isDisplayed();
			return Boolean;
			}
		public boolean Savebutton() {
			boolean Boolean = Save.isDisplayed();
			return Boolean;
			
		}
		public boolean CancelFeedRequestbutton() {
			boolean Boolean = CancelFeedRequest.isDisplayed();
			return Boolean;
	   }
		public void clickbackbutton() {
			Back.click();
		}
	
}

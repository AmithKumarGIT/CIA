package com.cia.qa.approvalflowpages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import cia.base.Testbaseapprovalflow;

public class Legalapproval extends Testbaseapprovalflow {
	//This is the object Repository for Legal approval Approval
	@FindBy(xpath="//textarea[@name='textarea']")
	WebElement textarea;
	@FindBy(id="approve_btn")
	WebElement Approvealbutton;
	//Initializing the page Objects:
		public Legalapproval() {
			PageFactory.initElements(driver, this);
		}
		//Actions
		public void providelegalapproval() {
			textarea.sendKeys("legalapproved");
			Approvealbutton.click();
		}
	}

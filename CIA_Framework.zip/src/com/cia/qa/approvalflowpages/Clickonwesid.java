package com.cia.qa.approvalflowpages;

import java.util.NoSuchElementException;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import cia.base.Testbaseapprovalflow;

public class Clickonwesid extends Testbaseapprovalflow {
	int proceed;
	//This is the object repository of wesid page
	@FindBy(linkText="098004")
	WebElement Wesidclick;
	//Initializing the page Objects:
	
			//boolean Boolean = false;
			public Clickonwesid() {
		    PageFactory.initElements(driver, this);
			}
			//Actions
			public int clickonwesids() {
			
				boolean Boolean = Wesidclick.isEnabled();
				if(Boolean) {
					Wesidclick.click();
				}
				else {
					System.out.println("This approval is not required");
					proceed=2;
				}
				return proceed;
				
			}
			/*public void clickonwesids() {
				try {
					Boolean = Wesidclick.isDisplayed();
					if(Boolean) {
						Wesidclick.click();
					}
				}catch(NoSuchElementException ex){
					System.out.println("LEGAL APPROVAL NOT REQUIRED");
				}
				catch (Exception e) {
					System.out.println("Unable to fine the WES ID");
				}
			}*/
}

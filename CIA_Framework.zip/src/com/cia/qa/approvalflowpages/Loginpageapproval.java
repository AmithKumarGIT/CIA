package com.cia.qa.approvalflowpages;

import java.io.IOException;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import cia.base.Testbaseapprovalflow;

public class Loginpageapproval extends Testbaseapprovalflow {
	//Page Factory  OBJECT Repository Till Login Page
		@FindBy(partialLinkText="More information")
		WebElement Moreinformation;
		@FindBy(partialLinkText="Go on to the webpage (not recommended)")
		WebElement Goontothewebpagenotrecommended;
		@FindBy(name="userid")
		WebElement userid;
		@FindBy(name="password")
		WebElement password;
		@FindBy(name="btnSubmit")
		WebElement btnSubmit;
		@FindBy(name="successOK")
		WebElement successOK;
		
		//Initializing the page Objects:
		public Loginpageapproval() {
			PageFactory.initElements(driver, this);
		}
		//Actions
		public void GotoLogin() {
			Moreinformation.click();
			Goontothewebpagenotrecommended.click();
			}
		public void loginpage(String un, String pwd) throws IOException 
		{
			userid.sendKeys(un);
			password.sendKeys(pwd);
			btnSubmit.click();
			successOK.click();
			}

}

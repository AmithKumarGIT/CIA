package com.cia.qa.approvalflowpages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import cia.base.Testbaseapprovalflow;

public class Approvefeedmenu extends Testbaseapprovalflow {
	//This is the object Repository of Cenet data Feed menu page
	@FindBy(xpath="//button[@ng-click='changetoApprovePath()']")
	WebElement clickapprovefeed;
	//@FindBy(linkText="096432")
	//WebElement Wesid;
	//Initializing the page Objects:
			public Approvefeedmenu() {
				PageFactory.initElements(driver, this);
			}
			//Actions
			public void Feedmenuforapproval() {
				clickapprovefeed.click();
				//Wesid.click();
				}

}

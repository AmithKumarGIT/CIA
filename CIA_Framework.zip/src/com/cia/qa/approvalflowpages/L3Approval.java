package com.cia.qa.approvalflowpages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import cia.base.Testbaseapprovalflow;

public class L3Approval extends Testbaseapprovalflow {
		//This is the object Repository for Legal approval Approval
			@FindBy(xpath="//textarea[@name='textarea']")
			WebElement textarea;
			@FindBy(id="approve_btn")
			WebElement Approvealbutton;
			@FindBy(id="fundReq_2")
			WebElement RequiredFund;
			@FindBy(linkText="Ok")
			WebElement OK;
			//Initializing the page Objects:
				public L3Approval() {
					PageFactory.initElements(driver, this);
				}
				//Actions
				public void provideL2approval() {
					textarea.sendKeys("L3 approved");
					RequiredFund.click();
					Approvealbutton.click();
				}
				public void ClickOK() {
					OK.click();
				}}

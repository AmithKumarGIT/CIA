package com.cia.qa.approvalflowpages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import cia.base.Testbaseapprovalflow;

public class L1approval extends Testbaseapprovalflow {
	//This is the object Repository for L1 Approval
	@FindBy(xpath="//textarea[@name='textarea']")
	WebElement textarea;
	@FindBy(id="approve_btn")
	WebElement Approvealbutton;
	@FindBy(linkText="Ok")
	WebElement OK;
	//Initializing the page Objects:
		public L1approval() {
			PageFactory.initElements(driver, this);
		}
		//Actions
		public void providel1approval() {
			textarea.sendKeys("L1Approved");
			Approvealbutton.click();
			OK.click();
		}
		}

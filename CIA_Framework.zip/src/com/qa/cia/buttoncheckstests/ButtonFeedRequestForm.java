package com.qa.cia.buttoncheckstests;

import java.io.IOException;

import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.cia.qa.buttoncheckpages.Buttonfeedrequestform;

import cia.base.Testbase;
import cia.pages.Loginpage;
import cia.test.AcknowledgePage;

public class ButtonFeedRequestForm extends Testbase {
	Loginpage loginpage;
	AcknowledgePage acknowledge;
	Buttonfeedrequestform Buttonfeedrequest;
	public ButtonFeedRequestForm() {
		super();
		}
	@BeforeTest()
	public void setup() throws IOException {
		initialization();
		loginpage = new Loginpage();
		loginpage.GotoLogin();
		loginpage.loginpage(prop.getProperty("username"), prop.getProperty("password"));
		acknowledge = new AcknowledgePage();
		acknowledge.acknowledge();
		}
	@Test
	public void ButtonFeedForm() {
		Buttonfeedrequest = new Buttonfeedrequestform();
		boolean Booleanback=Buttonfeedrequest.Backbutton();
		if(Booleanback) {
			System.out.println("Back button is enabled");
		}
		else {
			System.out.println("Back button is not enabled");
		}}
	@Test
	public void SavebuttonFeedForm() {
		boolean Booleansave=Buttonfeedrequest.Savebutton();
		Assert.assertEquals(Booleansave, true);
	}
	@Test
	public void CancelFeedForm() {
		Buttonfeedrequest = new Buttonfeedrequestform();
		boolean BooleanCancelbutton=Buttonfeedrequest.CancelFeedRequestbutton();
		Assert.assertEquals(BooleanCancelbutton, true);
	}
	/*@AfterTest()
	public void closedriver() {
		driver.quit();
	}*/
}

